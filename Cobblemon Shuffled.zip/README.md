Aims to fairly rebalance older and weaker pokemon to either fit a strong competitive niche better or better usability in casual battles.
